 Readme File:
============================================================

Vtf to tga converter

============================================================

 Installation

Right-click zip, choose EXPLORE and drag the 4 files into the folder where you have your tgas and run the batch file.
It will convert all the vtf files in a folder and, if you want, delete the originals after the conversion.
This will not convert tgas into vtfs. To convert the tgas back into vtfs, read my tutorial here:
http://elistutorials.blogspot.com/2004/12/tga-to-vtf-right-click-shortcut.html

============================================================

All original and composed assets in this level remain property of
the sources respective owners.
You MAY distribute this ZIP in any not-for-profit electronic format (BBS, Internet,
CD, etc) as long as you contact me first, and include all files, including this readme, intact in
the original archive.

============================================================